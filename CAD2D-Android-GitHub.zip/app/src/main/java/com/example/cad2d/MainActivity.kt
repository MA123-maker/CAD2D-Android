package com.example.cad2d

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.*
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(24,32,42))
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8,8,8,8)
            setBackgroundColor(Color.rgb(35,45,58))
        }

        fun button(label: String, action: () -> Unit): Button =
            Button(this).apply {
                text = label
                textSize = 12f
                setOnClickListener { action() }
            }

        val view = CadView(this)
        bar.addView(button("选择") { view.mode = Mode.SELECT })
        bar.addView(button("直线") { view.mode = Mode.LINE })
        bar.addView(button("矩形") { view.mode = Mode.RECT })
        bar.addView(button("圆") { view.mode = Mode.CIRCLE })
        bar.addView(button("撤销") { view.undo() })
        bar.addView(button("删除") { view.deleteSelected() })
        bar.addView(button("网格") { view.grid = !view.grid; view.invalidate() })
        bar.addView(button("清空") { view.clearAll() })

        root.addView(bar, LinearLayout.LayoutParams(-1, 58))
        root.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}

enum class Mode { SELECT, LINE, RECT, CIRCLE }

data class P(val x: Float, val y: Float)
sealed class Entity {
    data class Line(val a:P, val b:P): Entity()
    data class Rect(val a:P, val b:P): Entity()
    data class Circle(val c:P, val r:Float): Entity()
}

class CadView(context: android.content.Context) : View(context) {
    var mode = Mode.SELECT
    var grid = true
    private val items = mutableListOf<Entity>()
    private val history = mutableListOf<List<Entity>>()
    private var selected = -1
    private var start: P? = null
    private var preview: Entity? = null
    private var panX = 0f
    private var panY = 0f
    private var scale = 1f
    private var lastX = 0f
    private var lastY = 0f
    private var panning = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private fun saveState() {
        history.add(items.toList())
        if (history.size > 50) history.removeAt(0)
    }

    fun undo() {
        if (history.isNotEmpty()) {
            items.clear()
            items.addAll(history.removeAt(history.lastIndex))
            selected = -1
            invalidate()
        }
    }

    fun deleteSelected() {
        if (selected >= 0 && selected < items.size) {
            saveState()
            items.removeAt(selected)
            selected = -1
            invalidate()
        }
    }

    fun clearAll() {
        if (items.isNotEmpty()) saveState()
        items.clear(); selected = -1; invalidate()
    }

    private fun world(x:Float,y:Float): P =
        P((x-panX)/scale, (y-panY)/scale)

    private fun screen(p:P): P = P(p.x*scale+panX, p.y*scale+panY)

    private fun snap(p:P): P {
        val g=20f
        return P(round(p.x/g)*g, round(p.y/g)*g)
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(Color.rgb(24,32,42))
        if (grid) {
            paint.color = Color.rgb(48,65,82)
            paint.strokeWidth = 1f
            val step = 20f*scale
            if (step > 5) {
                var x = ((panX % step)+step)%step
                while (x < width) { c.drawLine(x,0f,x,height.toFloat(),paint); x+=step }
                var y = ((panY % step)+step)%step
                while (y < height) { c.drawLine(0f,y,width.toFloat(),y,paint); y+=step }
            }
        }
        items.forEachIndexed { i,e -> drawEntity(c,e,i==selected) }
        preview?.let { drawEntity(c,it,false, true) }
    }

    private fun drawEntity(c:Canvas,e:Entity,sel:Boolean,ghost:Boolean=false) {
        paint.color = when {
            ghost -> Color.rgb(134,239,172)
            sel -> Color.rgb(56,189,248)
            else -> Color.rgb(230,237,245)
        }
        paint.strokeWidth = if (sel) 4f else 2f
        when(e) {
            is Entity.Line -> {
                val a=screen(e.a); val b=screen(e.b)
                c.drawLine(a.x,a.y,b.x,b.y,paint)
            }
            is Entity.Rect -> {
                val a=screen(e.a); val b=screen(e.b)
                c.drawRect(min(a.x,b.x),min(a.y,b.y),max(a.x,b.x),max(a.y,b.y),paint)
            }
            is Entity.Circle -> {
                val p=screen(e.c)
                c.drawCircle(p.x,p.y,e.r*scale,paint)
            }
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val x=ev.x; val y=ev.y
        when(ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX=x; lastY=y
                val p=snap(world(x,y))
                if(mode==Mode.SELECT) {
                    selected = hit(p)
                    if(selected<0) panning=true
                    invalidate()
                } else {
                    start=p
                    preview = when(mode) {
                        Mode.LINE -> Entity.Line(p,p)
                        Mode.RECT -> Entity.Rect(p,p)
                        Mode.CIRCLE -> Entity.Circle(p,0f)
                        else -> null
                    }
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val p=snap(world(x,y))
                if(mode==Mode.SELECT && panning) {
                    panX += x-lastX; panY += y-lastY
                    lastX=x; lastY=y
                } else if(start!=null) {
                    val s=start!!
                    preview=when(mode) {
                        Mode.LINE -> Entity.Line(s,p)
                        Mode.RECT -> Entity.Rect(s,p)
                        Mode.CIRCLE -> Entity.Circle(s,hypot(p.x-s.x,p.y-s.y))
                        else -> null
                    }
                }
                invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                if(mode==Mode.SELECT) {
                    panning=false
                } else {
                    preview?.let { e ->
                        saveState(); items.add(e)
                    }
                    preview=null; start=null
                    invalidate()
                }
                return true
            }
        }
        return true
    }

    private fun hit(p:P): Int {
        val tol=12f/scale
        for(i in items.indices.reversed()) {
            when(val e=items[i]) {
                is Entity.Line -> if(distanceToSegment(p,e.a,e.b)<tol) return i
                is Entity.Rect -> {
                    val minx=min(e.a.x,e.b.x); val maxx=max(e.a.x,e.b.x)
                    val miny=min(e.a.y,e.b.y); val maxy=max(e.a.y,e.b.y)
                    if (abs(p.x-minx)<tol || abs(p.x-maxx)<tol || abs(p.y-miny)<tol || abs(p.y-maxy)<tol) return i
                }
                is Entity.Circle -> if(abs(hypot(p.x-e.c.x,p.y-e.c.y)-e.r)<tol) return i
            }
        }
        return -1
    }

    private fun distanceToSegment(p:P,a:P,b:P):Float {
        val dx=b.x-a.x; val dy=b.y-a.y
        val len2=dx*dx+dy*dy
        val t=((p.x-a.x)*dx+(p.y-a.y)*dy)/(if(len2==0f)1f else len2)
        val u=t.coerceIn(0f,1f)
        return hypot(p.x-(a.x+u*dx),p.y-(a.y+u*dy))
    }
}
